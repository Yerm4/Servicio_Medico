<div class="action-card">
                <h3 class="action-card__title">Historial de Consultas Médicas</h3>
                <div class="action-card__form--grid">
                    <label class="action-card__label">Buscar Paciente
                        <input type="text" id="paciente-search-buscar" class="action-card__input" placeholder="Escriba cédula o nombre del paciente..." autocomplete="off">
                        <input type="hidden" id="cedula_paciente_buscar">
                        <div id="pacientes-sugerencias-buscar" class="sugerencias-box" style="border: 1px solid #ccc; max-height: 200px; overflow-y: auto; display: none;"></div>
                    </label>
                </div>

                <!-- Contenedor para mostrar condiciones crónicas actuales del paciente en historial -->
                <div id="paciente-condiciones-info-buscar" style="margin-top: 10px; display: none; padding: 10px; background-color: #f9f9f9; border: 1px solid #eee; border-radius: 4px;"></div>

                <div id="consultas-lista-buscar" style="margin-top: 15px; max-height: 350px; overflow-y: auto;"></div>
            </div>
            <svg class="modal-crud__boton-cerrar" name="modalBotonCerrar" data-modal="modalBuscarConsulta" fill="#000000" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 460.775 460.775" xml:space="preserve">
                <path d="M285.08,230.397L456.218,59.27c6.076-6.077,6.076-15.911,0-21.986L423.511,4.565c-2.913-2.911-6.866-4.55-10.992-4.55c-4.127,0-8.08,1.639-10.993,4.55l-171.138,171.14L59.25,4.565c-2.913-2.911-6.866-4.55-10.993-4.55c-4.126,0-8.08,1.639-10.992,4.55L4.558,37.284c-6.077,6.075-6.077,15.909,0,21.986l171.138,171.128L4.575,401.505c-6.074,6.077-6.074,15.911,0,21.986l32.709,32.719c2.911,2.911,6.865,4.55,10.992,4.55c4.127,0,8.08-1.639,10.994-4.55l171.117-171.12l171.118,171.12c2.913,2.911,6.866,4.55,10.993,4.55c4.128,0,8.081-1.639,10.992-4.55l32.709-32.719c6.074-6.075,6.074-15.909,0-21.986L285.08,230.397z"/>
            </svg>